﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using Photo_Editor_2;
using System.Diagnostics;
using System.Drawing;
using Color = System.Drawing.Color;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using Pen = System.Drawing.Pen;
using System.Windows.Ink;

namespace Photo_Editor_2
{
    public partial class MainWindow : Window
    {
      Line line2 = new Line();

        System.Windows.Point currentpoint;

        Ellipse elip = new Ellipse();
        private double pointx;
        private double pointy;

        Line l1;
        int line = 0, circle = 0, r1=0, pen1=0;

        System.Windows.Point p1;

        public static int i = 0;
        public static double h = 582;
        public static double w = 1185;
        Bitmap c, c1, c2, c3, c4, c5, c6, c7, c8, c9;
        bool drag = false;
        System.Windows.Point startPoint;


        int x = 1, cr = 0;
        public List<double> FontSizes => new List<double> { 2, 4, 6, 8, 10,12,14,16,18,20,30,40,50,60,70,80,90,100 };


        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
            //MessageBox.Show(""+l1);
            //img.RenderTransformOrigin = sc1;

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            mcSlider.Value = 100;
            cr = 2;
            h = scr.ActualHeight;
            w = scr.ActualWidth;
           
            if (img.Source == null)
            {
                
                Microsoft.Win32.OpenFileDialog openFileDlg = new Microsoft.Win32.OpenFileDialog();
                Nullable<bool> result = openFileDlg.ShowDialog();
                openFileDlg.Title = "Open Image File";
                openFileDlg.DefaultExt = ".jpeg";
                openFileDlg.Filter = "Image files|*.jpg;*.png|All files|*.*";
                openFileDlg.FilterIndex = 1;
                try
                {
                    if (result == true)
                    {

                        Uri fileUri = new Uri(openFileDlg.FileName);
                        img.Source = new BitmapImage(fileUri);
                        c = new Bitmap(openFileDlg.FileName);
                        c1= new Bitmap(openFileDlg.FileName);
                        c2 = new Bitmap(openFileDlg.FileName);
                        c3 = new Bitmap(openFileDlg.FileName);
                        c4 = new Bitmap(openFileDlg.FileName);
                        c5 = new Bitmap(openFileDlg.FileName);
                        c6 = new Bitmap(openFileDlg.FileName);
                        c7 = new Bitmap(openFileDlg.FileName);
                        c8= new Bitmap(openFileDlg.FileName);
                        c9 = new Bitmap(openFileDlg.FileName);


                    }
                }
                catch
                {
                    MessageBox.Show("Please Select Image File");
                }
            }
            else
            {
                MessageBoxResult res = MessageBox.Show("Would you like to save current image", "Confirmation", MessageBoxButton.YesNoCancel);
                if (res == MessageBoxResult.Yes)
                {
                    cr = 2;

                    SaveFileDialog sfd = new SaveFileDialog();
                    sfd.FileName = "image.jpg";
                    sfd.Title = "Save Image File";
                    sfd.Filter = "Image files|*.jpg;*.png|All files|*.*";
                    sfd.InitialDirectory = System.IO.Directory.GetCurrentDirectory();
                    try
                    {
                        if (sfd.ShowDialog().Value)
                        {
                            var output_file = sfd.FileName;

                            // render the result canvas into a file
                            var v = img;
                            var encoder = new PngBitmapEncoder();
                            RenderTargetBitmap bitmap = new RenderTargetBitmap((int)img.ActualWidth, (int)img.ActualHeight, 50, 100, PixelFormats.Pbgra32);
                            bitmap.Render(v);
                            BitmapFrame frame = BitmapFrame.Create(bitmap);
                            encoder.Frames.Add(frame);

                            using (var stream = System.IO.File.Create(output_file))
                            {
                                encoder.Save(stream);
                            }
                        }

                        Microsoft.Win32.OpenFileDialog openFileDlg = new Microsoft.Win32.OpenFileDialog();
                        Nullable<bool> result = openFileDlg.ShowDialog();

                        if (result == true)
                        {
                            mcSlider.Value = 100;
                            Uri fileUri = new Uri(openFileDlg.FileName);

                            img.Source = new BitmapImage(fileUri);
                            c = new Bitmap(openFileDlg.FileName);
                            c1 = new Bitmap(openFileDlg.FileName);
                            c2 = new Bitmap(openFileDlg.FileName);
                            c3 = new Bitmap(openFileDlg.FileName);
                            c4 = new Bitmap(openFileDlg.FileName);
                            c5 = new Bitmap(openFileDlg.FileName);
                            c6 = new Bitmap(openFileDlg.FileName);
                            c7 = new Bitmap(openFileDlg.FileName);
                            c8 = new Bitmap(openFileDlg.FileName);
                            c9 = new Bitmap(openFileDlg.FileName);


                        }
                        selectionRectangle.Visibility = Visibility.Visible;
                        data.Visibility = Visibility.Hidden;

                    }
                    catch
                    {
                        Console.Write("");
                    }

                }
                else if (res == MessageBoxResult.No)
                {
                    cr = 2;
                    mcSlider.Value = 100;
                    Microsoft.Win32.OpenFileDialog openFileDlg = new Microsoft.Win32.OpenFileDialog();
                    Nullable<bool> result = openFileDlg.ShowDialog();

                    if (result == true)
                    {
                        Uri fileUri = new Uri(openFileDlg.FileName);

                        img.Source = new BitmapImage(fileUri);
                        c = new Bitmap(openFileDlg.FileName);
                        c1 = new Bitmap(openFileDlg.FileName);
                        c2 = new Bitmap(openFileDlg.FileName);
                        c3 = new Bitmap(openFileDlg.FileName);
                        c4 = new Bitmap(openFileDlg.FileName);
                        c5 = new Bitmap(openFileDlg.FileName);
                        c6 = new Bitmap(openFileDlg.FileName);
                        c7 = new Bitmap(openFileDlg.FileName);
                        c8 = new Bitmap(openFileDlg.FileName);
                        c9 = new Bitmap(openFileDlg.FileName);
                    }
                }
                else
                {
                    // res == MessageBoxResult.Cancel
                }

            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            cr = 2;

            //save button click
            try
            {
                if (img.Source != null)
            {
                SaveFileDialog sfd = new SaveFileDialog();
                sfd.FileName = "image.jpg";
                sfd.Title = "Save Image File";
                sfd.Filter = "Image files|*.jpg;*.png|All files|*.*";
                sfd.InitialDirectory = System.IO.Directory.GetCurrentDirectory();
              
                    if (sfd.ShowDialog().Value)
                    {
                        var output_file = sfd.FileName;

                        var v = img ;
                  
                        var encoder = new PngBitmapEncoder();
                        RenderTargetBitmap bitmap = new RenderTargetBitmap((int)img.ActualWidth, (int)img.ActualHeight,94.2, 96, PixelFormats.Pbgra32);
                        bitmap.Render(v);
                        BitmapFrame frame = BitmapFrame.Create(bitmap);
                        encoder.Frames.Add(frame);
                     
                        var p2 = canvas;
                       bitmap.Render(p2);                       

                        using (var stream = System.IO.File.Create(output_file))
                        {
                            encoder.Save(stream);                         
                        }

                    }
                }
            }
            catch
            {
                Console.Write("Please load the image");
            }
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            cr = 2;
            try
            {
                if (img.Source != null)
                {
                    SaveFileDialog sfd = new SaveFileDialog();
                    sfd.FileName = "image.jpg";
                    sfd.Title = "Save Image File";
                    sfd.Filter = "JPEG Compressed Image (*.jpg)|*.jpg|GIF Image(*.gif)|*.gif|Bitmap Image(*.bmp)|*.bmp|PNG Image (*.png)|*.png";
                    sfd.FilterIndex = 1;
                    sfd.RestoreDirectory = true;

                    if (sfd.ShowDialog().Value)
                    {
                        var output_file = sfd.FileName;

                        var v = img;
                        var encoder = new PngBitmapEncoder();
                        RenderTargetBitmap bitmap = new RenderTargetBitmap((int)img.ActualWidth, (int)img.ActualHeight, 50, 96, PixelFormats.Pbgra32);
                        bitmap.Render(v);
                        BitmapFrame frame = BitmapFrame.Create(bitmap);
                        encoder.Frames.Add(frame);

                        var p2 = canvas;
                        bitmap.Render(p2);


                        using (var stream = System.IO.File.Create(output_file))
                        {
                            encoder.Save(stream);
                        }
                    }
                }
            }
            catch
            {
                Console.Write("Please load the image");
            }
            
            
        }


        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            //menu item click open button
            Microsoft.Win32.OpenFileDialog openFileDlg = new Microsoft.Win32.OpenFileDialog();
            Nullable<bool> result = openFileDlg.ShowDialog();

            if (result == true)
            {
                Uri fileUri = new Uri(openFileDlg.FileName);
                img.Source = new BitmapImage(fileUri);
                c = new Bitmap(openFileDlg.FileName);
                c1 = new Bitmap(openFileDlg.FileName);
                c2 = new Bitmap(openFileDlg.FileName);
                c3 = new Bitmap(openFileDlg.FileName);
                c4 = new Bitmap(openFileDlg.FileName);
                c5 = new Bitmap(openFileDlg.FileName);
                c6 = new Bitmap(openFileDlg.FileName);
                c7 = new Bitmap(openFileDlg.FileName);
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            // Crop Button
            cr = 1;
            img.Cursor = Cursors.Cross;
            selectionRectangle.Visibility = Visibility.Visible;
              
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            //Zoom in
            cr = 2;

            img.Cursor = Cursors.Arrow;

            if (img.Height <= 4400 && img.Width <= 4950)
            {
                
                h *= 1.1;
                w *= 1.1;
                img.Height = h;
                img.Width = w;

               // MessageBox.Show("" + img.Height + "hj" + img.Width);
            }
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            cr = 2;
            img.Cursor = Cursors.Arrow;
            //Zoom out
            h /= 1.1;
            w /= 1.1;
            img.Height = h;
            img.Width = w;
          //  MessageBox.Show("" + img.Height + "hj" + img.Width);

        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            //add text
            try
            {
                if(img.Source!=null)
                    {
                    cr = 2;

                    img.Cursor = Cursors.Arrow;
                    text.Visibility = Visibility.Visible;
                    data.Visibility = Visibility.Visible;
                    data.Text = MyTextBox1.Text;

                    TextBlock textdata = new TextBlock();
                    textdata.Width = 100;
                    textdata.Height = 50;
                    textdata.MouseDown += textblock_MouseDown;
                    textdata.MouseMove += textblock_MouseMove;
                    textdata.MouseUp += textblock_MouseUp;
                    Canvas.SetLeft(textdata, 0);
                    Canvas.SetTop(textdata, 0);
                    canvas.Children.Add(textdata);
                }
            }
            catch
            {
                Console.Write("");
            }
        }
       
        private void textblock_MouseDown(object sender, MouseButtonEventArgs e)
        {
            drag = true;
            startPoint = e.GetPosition(canvas);
            
        }

        private void textblock_MouseMove(object sender, MouseEventArgs e)
        {
            if (drag)
            {
                TextBlock draggedText = sender as TextBlock;
                System.Windows.Point newPoint = e.GetPosition(canvas);
                double left = Canvas.GetLeft(draggedText);
                double top = Canvas.GetTop(draggedText);
                Canvas.SetLeft(draggedText, left + (newPoint.X - startPoint.X));
                Canvas.SetTop(draggedText, top + (newPoint.Y - startPoint.Y));

                startPoint = newPoint;
            }
        }

        private void textblock_MouseUp(object sender, MouseButtonEventArgs e)
        {
            // stop dragging
            drag = false;
        }


        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
           //Resize button
           
                img.Height = scr.ActualHeight;
                img.Width =scr.ActualWidth;
         //   MessageBox.Show("" + img.Height + "hj" + img.Width);


        }

        private void Button_Click_9(object sender, RoutedEventArgs e)
        {
            img.Cursor = Cursors.Arrow;
            int rotate_degree = -90;
            rotate_degree = rotate_degree * x;
            RotateTransform rotateTransform = new RotateTransform(rotate_degree);
            img.RenderTransform = rotateTransform;
            x++;

        }

        private void Button_Click_10(object sender, RoutedEventArgs e)
        {
            img.Cursor = Cursors.Arrow;
            int rotate_degree = 90;
            rotate_degree = rotate_degree * x;
            RotateTransform rotateTransform = new RotateTransform(rotate_degree);
            img.RenderTransform = rotateTransform;
            x++;   
        }

       
        private void rotate(int rotate_degree)
        {
            if (i == 1)
            {
                RotateTransform rotateTransform = new RotateTransform(-rotate_degree);
                img.RenderTransform = rotateTransform;
            }
            else if (i == 2)
            {
                RotateTransform rotateTransform = new RotateTransform(rotate_degree);
                img.RenderTransform = rotateTransform;
            }
           
        }

        private void Button_Click_12(object sender, RoutedEventArgs e)
        {
            cr = 2;
            img.Cursor = Cursors.Arrow;

            /*
                 string abc = MyTextBox1.Text;
               MyTextBox1.Clear();
               add_text.Content = abc;
               add_text.Visibility = Visibility.Visible;
               text.Visibility = Visibility.Hidden; */
            try
            {
                /* string str = MyTextBox1.Text;

                 PointF location = new PointF(200f, 50f);
                 using (Graphics graphics = Graphics.FromImage(c))
                 {
                     using (Font arialFont = new Font("Arial", 50))
                     {
                         graphics.DrawString(str, arialFont, System.Drawing.Brushes.DeepPink, location);
                     }
                 }
                 img.Source = ConvertBitmap(c);*/
                
                 text.Visibility = Visibility.Hidden;
                data.Visibility = Visibility.Visible;
                data.Text = MyTextBox1.Text;
                TextBlock textdata = new TextBlock();
                textdata.Width = 100;
                textdata.Height = 50;
                textdata.MouseDown += textblock_MouseDown;
                textdata.MouseMove += textblock_MouseMove;
                textdata.MouseUp += textblock_MouseUp;
         
                Canvas.SetLeft(textdata, 0);
                Canvas.SetTop(textdata, 0);
               
                canvas.Children.Add(textdata);
                MyTextBox1.Clear();
            }
            catch
            {
                Console.Write("Select Image");
                text.Visibility = Visibility.Hidden;

            }
        }
      


        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            img.Cursor = Cursors.Arrow;
            mcSlider.Value = 100;
            if (img.Source == null)
            {
                Microsoft.Win32.OpenFileDialog openFileDlg = new Microsoft.Win32.OpenFileDialog();
                Nullable<bool> result = openFileDlg.ShowDialog();

                if (result == true)
                {
                    Uri fileUri = new Uri(openFileDlg.FileName);
                    img.Source = new BitmapImage(fileUri);
                    c = new Bitmap(openFileDlg.FileName);
                    c1 = new Bitmap(openFileDlg.FileName);
                    c2 = new Bitmap(openFileDlg.FileName);
                    c3 = new Bitmap(openFileDlg.FileName);
                    c4 = new Bitmap(openFileDlg.FileName);
                    c5 = new Bitmap(openFileDlg.FileName);
                    c6 = new Bitmap(openFileDlg.FileName);
                    c7 = new Bitmap(openFileDlg.FileName);
                    c8 = new Bitmap(openFileDlg.FileName);
                    c9 = new Bitmap(openFileDlg.FileName);

                }
            }
            else
            {

                MessageBoxResult res = MessageBox.Show("Would you like to open a new image", "Confirmation", MessageBoxButton.YesNoCancel);
                if (res == MessageBoxResult.Yes)
                {
                    Microsoft.Win32.OpenFileDialog openFileDlg = new Microsoft.Win32.OpenFileDialog();
                    Nullable<bool> result = openFileDlg.ShowDialog();

                    if (result == true)
                    {
                        Uri fileUri = new Uri(openFileDlg.FileName);
                        img.Source = new BitmapImage(fileUri);
                    }
                }
                else if (res == MessageBoxResult.No)
                {

                }
                else
                {

                }
            }
        }
       
        private void Canvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (cr == 1)
            {

                var mousePosition = e.GetPosition(sender as UIElement);
                Canvas.SetLeft(selectionRectangle, mousePosition.X);
                Canvas.SetTop(selectionRectangle, mousePosition.Y);
                selectionRectangle.Visibility = System.Windows.Visibility.Visible;
            }
            if (line == 1)
            {
                p1 = e.GetPosition(canvas);
                l1 = new Line() { Stroke = new SolidColorBrush { Color = Colors.Black }, StrokeThickness = 3 };
                l1.X1 = p1.X;
                l1.Y1 = p1.Y;
                canvas.Children.Add(l1);
            }
            if (circle == 1)
            {
                System.Windows.Point location = e.MouseDevice.GetPosition(canvas);
                elip = new Ellipse();
                elip.Height = 1;
                elip.Width = 1;
                elip.Stroke = System.Windows.Media.Brushes.Black;
                elip.StrokeThickness = 2;
                Canvas.SetTop(elip, location.Y + 1);
                Canvas.SetLeft(elip, location.X + 1);
                pointx = location.X + 1;
                pointy = location.Y + 1;
                canvas.Children.Add(elip);
            }
            if (r1 == 1)
            {
                st = e.GetPosition(this);

            }
            if (pen1== 1)
            {
                if (e.ButtonState == MouseButtonState.Pressed)
                    currentpoint = e.GetPosition(this);
            }
            st = e.GetPosition(this);
        }

        private void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            try{


                if (e.LeftButton == MouseButtonState.Pressed)
                {
                    if (cr == 1)
                    {
                        var mousePosition = e.GetPosition(sender as UIElement);
                        selectionRectangle.Width = mousePosition.X - Canvas.GetLeft(selectionRectangle);
                        selectionRectangle.Height = mousePosition.Y - Canvas.GetTop(selectionRectangle);
                    }
                    if (line == 1)
                    {
                        var p2 = e.GetPosition(canvas);
                        l1.X2 = p2.X;
                        l1.Y2 = p2.Y;
                    }
                    if (circle == 1)
                    {
                        System.Windows.Point location = e.MouseDevice.GetPosition(canvas);
                        double height = location.Y - pointy;
                        double width = location.X - pointx;
                        if (height >= 0 && width >= 0)
                        {
                            elip.Height = height;
                            elip.Width = width;
                        }
                        else if (height < 0 || width < 0)
                        {
                            if (height < 0)
                            {
                                elip.Height = height + (-height) + 1;
                                elip.Width = width;
                            }
                            else if (width < 0)
                            {
                                elip.Height = height;
                                elip.Width = width + (-width) + 1;
                            }
                        }
                    }
                    if (r1==1)
                    {
                        end = e.GetPosition(this);

                    }

                }
                if (pen1 == 1)
                {
                    if (e.LeftButton == MouseButtonState.Pressed)
                    {
                        Line line2 = new Line();

                        line2.Stroke = System.Windows.Media.Brushes.Black;
                        line2.StrokeThickness = 3;
                        line2.X1 = currentpoint.X;
                        line2.Y1 = currentpoint.Y;
                        line2.X2 = e.GetPosition(this).X;
                        line2.Y2 = e.GetPosition(this).Y;

                        currentpoint = e.GetPosition(this);

                        canvas.Children.Add(line2);
                    }
                }
            }
            catch
            {
                Console.Write("Please select area");
            }

        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            //button crop
            try
            {
                
                Rect r1 = new Rect(Canvas.GetLeft(selectionRectangle), Canvas.GetTop(selectionRectangle), selectionRectangle.Width, selectionRectangle.Height);
                System.Windows.Int32Rect r2 = new System.Windows.Int32Rect();
                r2.X = (int)((r1.X) * (img.Source.Width) / (img.Width));
                r2.Y = (int)((r1.Y) * (img.Source.Height) / (img.Height));
                r2.Width = (int)((r1.Width) * (img.Source.Width) / (img.Width));
                r2.Height = (int)((r1.Height) * (img.Source.Height) / (img.Height));
                BitmapSource bs = new CroppedBitmap(img.Source as BitmapSource, r2);
                img.Source = bs;

                selectionRectangle.Visibility = Visibility.Hidden;

            }

            catch
            {
                Console.Write("Select crop area");
            }
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            try
            {
                if (img.Source != null)
                {
                    Bitmap d;

                    int x, y;


                    for (x = 0; x < c2.Width; x++)
                    {
                        for (y = 0; y < c2.Height; y++)
                        {
                            Color pixelColor = c2.GetPixel(x, y);
                            Color newColor = Color.FromArgb(pixelColor.R, 0, 0);
                            c2.SetPixel(x, y, newColor); // Now greyscale
                        }
                    }

                    d = c2;

                    img.Source = ConvertBitmap(d);
                }
            }
            catch
            {
                Console.Write("Please select image");
            }

        }
  
        private void MenuItem_Click_4(object sender, RoutedEventArgs e)
        {
            try
            {
                if (img.Source != null)
                {
                    Bitmap d;

                    int x, y;


                    for (x = 0; x < c3.Width; x++)
                    {
                        for (y = 0; y < c3.Height; y++)
                        {
                            Color pixelColor = c3.GetPixel(x, y);
                            Color newColor = Color.FromArgb(0, 0, pixelColor.B);
                            c3.SetPixel(x, y, newColor); // Now greyscale
                        }
                    }
                    d = c3;

                    img.Source = ConvertBitmap(d);
                }
            }
            catch
            {
                Console.Write("Please select image");
            }


        }

        private void MenuItem_Click_5(object sender, RoutedEventArgs e)
        {
            try
            {
                if (img.Source != null)
                {
                    Bitmap d;

                    int x, y;


                    for (x = 0; x < c4.Width; x++)
                    {
                        for (y = 0; y < c4.Height; y++)
                        {
                            Color pixelColor = c4.GetPixel(x, y);
                            Color newColor = Color.FromArgb(0, pixelColor.G, 0);
                            c4.SetPixel(x, y, newColor); // Now greyscale
                        }
                    }
                    d = c4;

                    img.Source = ConvertBitmap(d);
                }
            }
            catch
            {
                Console.Write("Please select image");
            }

        }

        private void mcSlider_ValueChanged_1(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            try
            {
                img.Cursor = Cursors.Arrow;

                img.Opacity = mcSlider.Value / 100;
            }
            catch
            {
                Console.Write("");
            }
        }

        private void ComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            /*  
             data.FontSize = Convert.ToDouble(cmb.Text);
          try
             {
                 int d1 = Convert.ToInt32((data.FontSize));
                 string s1 = cmb.Text;
                 d1 = Convert.ToInt32(s1);
                 data.FontSize = d1;

             }
             catch
             {
                 Console.Write("");
             }*/
        }
        private void MenuItem_Click_34(object sender, RoutedEventArgs e)
        {
            pen1 = 0;
            circle = 0;
            r1 = 0;
            line = 1;
        }

        private void MenuItem_Click_36(object sender, RoutedEventArgs e)
        {
            pen1 = 0;
            line = 0;
            r1 = 0;
            circle = 1;
        }

        private void MenuItem_Click_37(object sender, RoutedEventArgs e)
        {
            pen1 = 0;
            line = 0;
            circle = 0;
            r1 = 1;
            
        }
        private void MenuItem_Click_38(object sender, RoutedEventArgs e)
        {
            line = 0;
            circle = 0;
            r1 = 0;
            pen1 = 1;

        }
      
        private void MenuItem_Click_35(object sender, RoutedEventArgs e)
        {
            if (line==1)
            {
                canvas.Children.RemoveAt(canvas.Children.Count - 1);
            }
            if(circle==1)
            {
                canvas.Children.RemoveAt(canvas.Children.Count - 1);

            }
            if (r1 == 1)
            {
                canvas.Children.RemoveAt(canvas.Children.Count - 1);

            }
            if (pen1 == 1)
            {
                canvas.Children.RemoveAt(canvas.Children.Count - 1);

            }
            if (r1 == 1)
            {
                canvas.Children.RemoveAt(canvas.Children.Count -1);

            }
        }

        private void MenuItem_Click_27(object sender, RoutedEventArgs e)
        {
            data.Visibility = Visibility.Hidden;
        }

        private void MenuItem_Click_6(object sender, RoutedEventArgs e)
        {

            try
            {
                if (img.Source != null)
                {


                    Bitmap d;

                    int x, y;


                    for (x = 0; x < c5.Width; x++)
                    {
                        for (y = 0; y < c.Height; y++)
                        {
                            Color pixelColor = c5.GetPixel(x, y);
                            int a = pixelColor.A;
                            int r = pixelColor.R;
                            int g = pixelColor.G;
                            int b = pixelColor.B;
                            int avg = (r + g + b) / 3;
                            c5.SetPixel(x, y, Color.FromArgb(a, avg, avg, avg));
                        }
                    }
                    d = c5;

                    img.Source = ConvertBitmap(d);
                }
            }
            catch
            {
                Console.Write("Please Load image");
            }         
        }

        

        private void MenuItem_Click_7(object sender, RoutedEventArgs e)
        {
            try
            {
                if (img.Source != null)
                {
                    Bitmap d;

                    int x, y;


                    for (x = 0; x < c6.Width; x++)
                    {
                        for (y = 0; y < c6.Height; y++)
                        {
                            Color pixelColor = c6.GetPixel(x, y);
                            Color newColor = Color.FromArgb(255 - pixelColor.R, 255 - pixelColor.G, 255 - pixelColor.B);
                            c6.SetPixel(x, y, newColor);
                        }
                    }
                    d = c6;

                    img.Source = ConvertBitmap(d);
                }
            }
            catch
            {
                Console.Write("Please select image");
            }
        }

        private void MenuItem_Click_9(object sender, RoutedEventArgs e)
        {
            try
            {
                if (img.Source != null)
                {
                    Bitmap d;


                    int[,] gx =
                    {
                { -1, 0, 1 },
                { -2, 0, 2 },
                { -1, 0, 1 }
            };
                    int[,] gy =
                    {
                { 1, 2, 1 },
                { 0, 0, 0 },
                { -1, -2, -1 }
            };

                    int width = c7.Width;
                    int height = c7.Height;

                    int[,] allPixR = new int[width, height];
                    int[,] allPixG = new int[width, height];
                    int[,] allPixB = new int[width, height];

                    //create matrices with RGb values
                    int limit = 128 * 128;
                    for (int i = 0; i < width; i++)
                    {
                        for (int j = 0; j < height; j++)
                        {
                            allPixR[i, j] = c7.GetPixel(i, j).R;
                            allPixG[i, j] = c7.GetPixel(i, j).G;
                            allPixB[i, j] = c7.GetPixel(i, j).B;
                        }
                    }

                    for (int i = 1; i < width - 1; i++)
                    {
                        for (int j = 1; j < height - 1; j++)
                        {

                            var Rx = 0;
                            var Ry = 0;
                            var Gx = 0;
                            var Gy = 0;
                            var Bx = 0;
                            var By = 0;

                            for (int wi = -1; wi < 2; wi++)
                            {
                                for (int hw = -1; hw < 2; hw++)
                                {
                                    var rc = allPixR[i + hw, j + wi];
                                    Rx += gx[wi + 1, hw + 1] * rc;
                                    Ry += gy[wi + 1, hw + 1] * rc;

                                    var gc = allPixG[i + hw, j + wi];
                                    Gx += gx[wi + 1, hw + 1] * gc;
                                    Gy += gy[wi + 1, hw + 1] * gc;

                                    var bc = allPixB[i + hw, j + wi];
                                    Bx += gx[wi + 1, hw + 1] * bc;
                                    By += gy[wi + 1, hw + 1] * bc;
                                }
                            }

                            if (Rx * Rx + Ry * Ry > limit ||
                                Gx * Gx + Gy * Gy > limit ||
                                Bx * Bx + By * By > limit)
                                c7.SetPixel(i, j, Color.Black);
                            else
                                c7.SetPixel(i, j, Color.Transparent);
                        }
                    }

                    d = c7;
                    img.Source = ConvertBitmap(d);
                }
            }
            catch
            {
                Console.Write("Please select Image");
            }
        }
        

        private void MenuItem_Click_11(object sender, RoutedEventArgs e)
        {
           
            try {
                if (img.Source != null)
                {
                    Bitmap d;
                    for (int y = 1; y < c8.Height - 1; y++)
                    {
                        for (int x = 1; x < c8.Width - 1; x++)
                        {
                            var p1 = c8.GetPixel(x - 1, y - 1);
                            var p2 = c8.GetPixel(x, y - 1);
                            var p3 = c8.GetPixel(x + 1, y - 1);

                            var p4 = c8.GetPixel(x - 1, y);
                            var p5 = c8.GetPixel(x, y);
                            var p6 = c8.GetPixel(x + 1, y);

                            var p7 = c8.GetPixel(x - 1, y + 1);
                            var p8 = c8.GetPixel(x, y + 1);
                            var p9 = c8.GetPixel(x + 1, y + 1);

                            var avgR = (p1.R + p2.R + p3.R + p4.R + p5.R + p6.R + p7.R + p8.R + p9.R) / 9;
                            var avgG = (p1.G + p2.G + p3.G + p4.G + p5.G + p6.G + p7.G + p8.G + p9.G) / 9;
                            var avgB = (p1.B + p2.B + p3.B + p4.B + p5.B + p6.B + p7.B + p8.B + p9.B) / 9;

                            c8.SetPixel(x, y, Color.FromArgb(p5.A, avgR, avgG, avgB));

                        }
                    }

                    d = c8;
                    img.Source = ConvertBitmap(d);

                }
            }
            catch
            {
                Console.Write("Select Image");

            }

        }

        private void MenuItem_Click_8(object sender, RoutedEventArgs e)
        {
            try
            {
                if (img.Source != null)
                {
                    img.Source = ConvertBitmap(c1);
                }
            }
            catch
            {
                Console.Write("Please select image");
            }
        }
        
            private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
            {
            try
            {
                if (img.Source != null)
                {
                    img.Source = ConvertBitmap(AdjustBrightness(c, (float)(s1.Value)));
                }
            }
            catch
            {
                Console.Write("Select Image");
            }
        }
            private Bitmap AdjustBrightness(Bitmap image, float brightness)
            {
                
                float b = brightness;
                ColorMatrix cm = new ColorMatrix(new float[][]
                    {
                    new float[] {b, 0, 0, 0, 0},
                    new float[] {0, b, 0, 0, 0},
                    new float[] {0, 0, b, 0, 0},
                    new float[] {0, 0, 0, 1, 0},
                    new float[] {0, 0, 0, 0, 1},
                    });
                ImageAttributes attributes = new ImageAttributes();
                attributes.SetColorMatrix(cm);

            System.Drawing.Point[] points =
                {
                new System.Drawing.Point(0, 0),
                new System.Drawing.Point(image.Width, 0),
                new System.Drawing.Point(0, image.Height),
            };
            System.Drawing.Rectangle rect = new System.Drawing.Rectangle(0, 0, image.Width, image.Height);

                Bitmap bm = new Bitmap(image.Width, image.Height);
                using (Graphics gr = Graphics.FromImage(bm))
                {
                    gr.DrawImage(image, points, rect, GraphicsUnit.Pixel, attributes);
                }

                return bm;
            }

        private void MenuItem_Click_10(object sender, RoutedEventArgs e)
        {
            try
            {
                if (img.Source != null)
                {
                    c.RotateFlip(RotateFlipType.RotateNoneFlipX);
                    Bitmap d;
                    d = c;
                    img.Source = ConvertBitmap(d);
                }
            }
            catch
            {
                Console.Write("Select Image");
            }
        }

        public BitmapImage ConvertBitmap(System.Drawing.Bitmap bitmap)
        {
            MemoryStream ms = new MemoryStream();
            bitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Bmp);
            BitmapImage image = new BitmapImage();
            image.BeginInit();
            ms.Seek(0, SeekOrigin.Begin);
            image.StreamSource = ms;
            image.EndInit();

            return image;
        }

        // private void img_MouseMove(object sender, MouseEventArgs e)
        // {


        //  System.Windows.Point p = e.GetPosition(this);
        //double p1 = p.X;
        //double p2 = p.Y;

        //img.Width = p1;
        //img.Height = p2;
        //}

        private void MenuItem_Click_12(object sender, RoutedEventArgs e)
        {
            data.Foreground = System.Windows.Media.Brushes.Red;

        }

        private void MenuItem_Click_13(object sender, RoutedEventArgs e)
        {
            data.Foreground = System.Windows.Media.Brushes.Blue;


        }

        private void MenuItem_Click_14(object sender, RoutedEventArgs e)
        {
            data.Foreground = System.Windows.Media.Brushes.Green;

        }

        private void MenuItem_Click_15(object sender, RoutedEventArgs e)
        {
            data.Foreground = System.Windows.Media.Brushes.Yellow;

        }

        private void MenuItem_Click_16(object sender, RoutedEventArgs e)
        {
            data.Foreground = System.Windows.Media.Brushes.Brown;

        }

        private void MenuItem_Click_17(object sender, RoutedEventArgs e)
        {
            data.Foreground = System.Windows.Media.Brushes.Orange;

        }

        private void MenuItem_Click_18(object sender, RoutedEventArgs e)
        {
            data.Foreground = System.Windows.Media.Brushes.White;

        }

        private void MenuItem_Click_19(object sender, RoutedEventArgs e)
        {
            data.Foreground = System.Windows.Media.Brushes.Black;

        }


        private void MenuItem_Click_20(object sender, RoutedEventArgs e)
        {
            data.Foreground = System.Windows.Media.Brushes.Purple;

        }

        private void MenuItem_Click_21(object sender, RoutedEventArgs e)
        {
            data.FontFamily = new System.Windows.Media.FontFamily("Arial");

        }

        private void MenuItem_Click_22(object sender, RoutedEventArgs e)
        {
            data.FontFamily = new System.Windows.Media.FontFamily("Comic Sans MS");

        }

        private void MenuItem_Click_23(object sender, RoutedEventArgs e)
        {
            data.FontFamily = new System.Windows.Media.FontFamily("Corbel");

        }

        private void MenuItem_Click_24(object sender, RoutedEventArgs e)
        {
            data.FontFamily = new System.Windows.Media.FontFamily("Constantia");

        }

        private void canvas_MouseUp(object sender, MouseButtonEventArgs e)
        { 
            if(r1==1)
            Rect();
        }

        private void MenuItem_Click_25(object sender, RoutedEventArgs e)
        {
            data.FontFamily = new System.Windows.Media.FontFamily("Times New Roman");

        }

        private void MenuItem_Click_26(object sender, RoutedEventArgs e)
        {
            data.FontFamily = new System.Windows.Media.FontFamily("Century Gothic");

        }

        private void MenuItem_Click_28(object sender, RoutedEventArgs e)
        {
            data.Foreground = System.Windows.Media.Brushes.Indigo;

        }

        private void MenuItem_Click_29(object sender, RoutedEventArgs e)
        {
            data.Foreground = System.Windows.Media.Brushes.DarkBlue;

        }

        private void MenuItem_Click_30(object sender, RoutedEventArgs e)
        {
            data.Foreground = System.Windows.Media.Brushes.White;

        }

        private void MenuItem_Click_31(object sender, RoutedEventArgs e)
        {
            data.Foreground = System.Windows.Media.Brushes.Gray;

        }

        private void MenuItem_Click_32(object sender, RoutedEventArgs e)
        {
            data.Foreground = System.Windows.Media.Brushes.Gold;

        }

        private void MenuItem_Click_33(object sender, RoutedEventArgs e)
        {
            data.Foreground = System.Windows.Media.Brushes.Magenta;

        }

        System.Windows.Point st;
        System.Windows.Point end;
        private void Rect()
        {
            System.Windows.Shapes.Rectangle newrect = new System.Windows.Shapes.Rectangle()
            {
                Stroke = System.Windows.Media.Brushes.Black, StrokeThickness = 3, Height = 10, Width = 10
            
            };
            if (end.X>=st.X)
            {
                newrect.SetValue(Canvas.LeftProperty, st.X);
                newrect.Width = end.X - st.X;
            }
            else
            {
                newrect.SetValue(Canvas.LeftProperty, end.X);
                newrect.Width =  st.X - end.X ;
            }
            if (end.Y >= st.Y)
            {
                newrect.SetValue(Canvas.TopProperty, st.Y-50);
                newrect.Height = end.Y - st.Y;
            }
            else
            {
                newrect.SetValue(Canvas.TopProperty, end.Y - 50);
                newrect.Height = st.Y - end.Y;
            }
            canvas.Children.Add(newrect);
        }

    }
}


